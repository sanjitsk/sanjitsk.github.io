# main.py — request “FSTE00FS” every 10 s, publish temp→SUB, motor commands→PUB

import time
import uasyncio as asyncio
from machine import UART
from mqtt_as.mqtt_as import MQTTClient
from mqtt_as.mqtt_local import config

# ─── UART1 on GPIO17=TX, GPIO18=RX @9600bps ────────────────────────────────
uart = UART(1, baudrate=9600, tx=17, rx=18)
time.sleep_ms(200)
while uart.any():
    uart.read()  # flush startup junk

# ─── Wi-Fi creds ─────────────────────────────────────────────────────────────
config['ssid']    = 'testwifi'
config['wifi_pw'] = 'testpass'

# ─── MQTT broker ─────────────────────────────────────────────────────────────
config['server'] = 'mqtt.eclipseprojects.io'
config['port']   = 1883
config['ssl']    = False
config['clean']  = True

# ─── Topics & 8-byte frames ───────────────────────────────────────────────────
TOPIC_TEMP   = b'test/sanjit/SUB'   # where we publish received temps
TOPIC_STATE  = b'test/sanjit/PUB'   # where we publish ON/OFF/REV

# Frames must be exactly 8 bytes: 'F','S', sender, receiver, D1, D2, 'F','S'
CMD_REQ      = b'FSTE00FS'  # FS, T→E, payload "00", FS  → ask PIC (E) for new temp
CMD_ON       = b'FSTS02FS'  # FS, T→S, "02", FS
CMD_OFF      = b'FSTS01FS'  # FS, T→S, "01", FS
CMD_REV      = b'FSTS03FS'  # FS, T→S, "03", FS

# ─── Helpers ─────────────────────────────────────────────────────────────────
def uart_send(frame: bytes):
    uart.write(frame)
    print('UART ▶', frame)

async def publish(topic: bytes, msg: bytes):
    await client.publish(topic, msg, qos=1)
    print('✓ MQTT PUB', topic, msg)

# ─── Task A: every 10s send the “ask temp” frame ─────────────────────────────
async def requester():
    await asyncio.sleep(1)  # brief boot delay
    while True:
        uart_send(CMD_REQ)
        await asyncio.sleep(10)

# ─── Task B: read exactly 8-byte replies, decode & drive logic ───────────────
async def uart_listener():
    reader = asyncio.StreamReader(uart)
    print('▶ UART listener running')
    while True:
        data = await reader.read(8)
        if not data or len(data) != 8:
            await asyncio.sleep_ms(50)
            continue

        print('UART ◀', data)

        # 1) check header/footer
        if data[0:2] != b'FS' or data[6:8] != b'FS':
            print('⚠️ Invalid frame:', data)
            continue

        sender   = chr(data[2])
        receiver = chr(data[3])

        # 2) make sure it's addressed to us ('T')
        if receiver != 'T':
            # not for this node → ignore
            continue

        # 3) parse ASCII-digit payload
        try:
            tens = data[4] - ord('0')
            ones = data[5] - ord('0')
            if not (0 <= tens <= 9 and 0 <= ones <= 9):
                raise ValueError
            temp = tens * 10 + ones
        except Exception:
            print('⚠️ Bad payload bytes:', data[4], data[5])
            continue

        # 4) publish temperature
        await publish(TOPIC_TEMP, str(temp).encode())
  
        # 5) decide motor command
        if temp <= 20:
            uart_send(CMD_REV)
            await publish(TOPIC_STATE, b'REV')
        elif temp <= 34:
            uart_send(CMD_OFF)
            await publish(TOPIC_STATE, b'OFF')
        else:
            uart_send(CMD_ON)
            await publish(TOPIC_STATE, b'ON')

        await asyncio.sleep_ms(50)

# ─── MQTT client setup & entrypoint ─────────────────────────────────────────
MQTTClient.DEBUG = False
client = MQTTClient(config)

async def main():
    print('▶ Connecting Wi-Fi+MQTT…')
    await client.connect()
    print('✔ MQTT connected')

    # start both coroutines
    asyncio.create_task(requester())
    asyncio.create_task(uart_listener())

    # keep-alive
    while True:
        await asyncio.sleep(1)

try:
    asyncio.run(main())
finally:
    client.close()
